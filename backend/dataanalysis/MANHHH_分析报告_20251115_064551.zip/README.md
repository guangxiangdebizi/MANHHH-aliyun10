# MANHHH 项目数据分析

## 📊 功能说明

本数据分析模块用于分析 MANHHH 项目的运营数据，包括：

- ✅ 用户统计（总数、新增、活跃度等）
- ✅ 会话统计（总会话数、对话数、消息数）
- ✅ 工具调用统计（哪些工具最常用）
- ✅ 用户提问词云分析
- ✅ 用户增长趋势图
- ✅ 聊天活跃度图表
- ✅ 详细的数据报告

## 🚀 使用方法

### 1. 安装依赖

```bash
pip install matplotlib jieba wordcloud pandas numpy
```

### 2. 运行分析

```bash
cd /home/ec2-user/AIWebHere/MANHHH-aliyun10/backend/dataanalysis
python analyze.py
```

### 3. 查看结果

分析结果会保存在 `output/` 目录下：

- `analysis_report.txt` - 文本分析报告
- `analysis_data.json` - 原始数据（JSON格式）
- `questions_wordcloud.png` - 用户提问词云图
- `user_growth.png` - 用户增长趋势图
- `chat_activity.png` - 聊天活跃度图
- `tool_usage.png` - 工具使用统计图

## 📝 输出示例

```
==============================================================
MANHHH 项目数据分析报告
==============================================================
生成时间: 2025-01-15 10:30:00

【用户统计】
  总用户数: 150
  有邮箱用户: 120
  配置了 Tushare Token: 45
  启用了 Tushare Token: 30
  最近7天新增: 12
  最近30天新增: 58
  积分平均值: 42.5
  积分范围: 0 - 100

【聊天统计】
  总会话数: 3500
  总对话数: 8200
  总消息数: 25600
  最近7天消息: 1800
  最近30天消息: 7500
  人均消息数: 170.67

【最活跃用户 TOP 10】
  1. user123: 850 条消息
  2. user456: 620 条消息
  ...

【工具调用统计 TOP 10】
  1. tushare_index_constituents_summary: 320 次
  2. search_medical_data: 280 次
  ...
```

## 🎨 图表说明

### 用户提问词云
- 展示用户最常提问的关键词
- 字体大小代表词频高低
- 自动过滤停用词

### 用户增长趋势
- 上图：每日新增用户数
- 下图：累计用户增长曲线

### 聊天活跃度
- 最近30天的每日消息数
- 可以看出系统使用的活跃时段

### 工具使用统计
- 横向柱状图展示各工具调用次数
- 显示 TOP 15 最常用工具

## 🔧 自定义分析

如需自定义分析，可以修改 `analyze.py` 脚本：

```python
# 修改词云停用词
stop_words = set(['的', '了', ...])

# 修改图表样式
plt.figure(figsize=(16, 8))  # 调整大小
plt.colormap('viridis')      # 修改颜色

# 添加新的统计维度
# 在脚本中添加自定义 SQL 查询和可视化
```

## 📦 文件结构

```
dataanalysis/
├── README.md           # 本说明文档
├── analyze.py          # 主分析脚本
├── SimHei.ttf          # 中文字体（自动下载）
└── output/             # 输出目录
    ├── analysis_report.txt
    ├── analysis_data.json
    ├── questions_wordcloud.png
    ├── user_growth.png
    ├── chat_activity.png
    └── tool_usage.png
```

## 💡 注意事项

1. **中文字体**：脚本会自动下载中文字体，如下载失败会尝试使用系统字体
2. **数据隐私**：分析结果中不包含敏感信息（密码、Token等）
3. **性能**：大数据量时分析可能需要几分钟
4. **定期运行**：建议定期运行以跟踪项目发展趋势

## 🔄 定时分析

可以使用 cron 定时运行分析：

```bash
# 编辑 crontab
crontab -e

# 添加每天凌晨2点运行分析
0 2 * * * cd /home/ec2-user/AIWebHere/MANHHH-aliyun10/backend/dataanalysis && python analyze.py >> analysis.log 2>&1
```

